﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class AdminAnnouncements : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    // Use the signupId to fetch membership information
                    BindData();
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }
        private void BindData()
        {
            // Define your connection string
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            // Create a new SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                // Create a new SQL command
                using (SqlCommand command = new SqlCommand("SELECT * FROM Announcements", connection))
                {
                    // Execute the command and get the data
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Bind the data to the GridView
                        AnnouncementsGridView.DataSource = reader;
                        AnnouncementsGridView.DataBind();
                    }
                }
            }
        }

        private void UpdateAnnouncementInDatabase(int announcementID, string newTitle, string newContent)
        {
            // Define your connection string
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            // Create a new SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                // Create a new SQL command
                using (SqlCommand command = new SqlCommand("UPDATE Announcements SET Title = @Title, Content = @Content, DateUpdated = @DateUpdated WHERE AnnouncementID = @AnnouncementID", connection))
                {
                    // Add the parameters
                    command.Parameters.AddWithValue("@AnnouncementID", announcementID);
                    command.Parameters.AddWithValue("@Title", newTitle);
                    command.Parameters.AddWithValue("@Content", newContent);
                    command.Parameters.AddWithValue("@DateUpdated", DateTime.Now);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }
        }
        private void DeleteAnnouncementFromDatabase(int announcementID)
        {
            // Define your connection string
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            // Create a new SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                // Create a new SQL command
                using (SqlCommand command = new SqlCommand("DELETE FROM Announcements WHERE AnnouncementID = @AnnouncementID", connection))
                {
                    // Add the parameter
                    command.Parameters.AddWithValue("@AnnouncementID", announcementID);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }
        }
        protected void UpdateButton_Click(object sender, EventArgs e)
        {
            // Get the button that raised the event
            Button btn = (Button)sender;

            // Get the GridViewRow containing the button
            GridViewRow row = (GridViewRow)btn.NamingContainer;

            // Find the TextBox controls in the row
            TextBox titleTextBox = (TextBox)row.FindControl("NewTitle");
            TextBox contentTextBox = (TextBox)row.FindControl("NewContent");

            // Get the text from the TextBox controls
            string newTitle = titleTextBox.Text;
            string newContent = contentTextBox.Text;
            // Check if the new title or content is empty or only contains white spaces
            if (string.IsNullOrWhiteSpace(newTitle) || string.IsNullOrWhiteSpace(newContent))
            {
                // Find the Label control in the row
                Label errorMessageLabel = (Label)row.FindControl("ErrorMessageLabel");

                // Display an error message
                errorMessageLabel.Text = "Title and content cannot be empty.";
                return;
            }
            // Get the announcement ID from the button's CommandArgument property
            int announcementID = int.Parse(btn.CommandArgument);

            // Update the announcement in the database
            UpdateAnnouncementInDatabase(announcementID, newTitle, newContent);

            // Refresh the data in the GridView
            BindData();
            Response.Redirect(Request.RawUrl);
        }
        protected void DeleteButton_Click(object sender, EventArgs e)
        {
            // Get the button that raised the event
            Button btn = (Button)sender;

            // Get the announcement ID from the button's CommandArgument property
            int announcementID = int.Parse(btn.CommandArgument);

            // Delete the announcement from the database
            DeleteAnnouncementFromDatabase(announcementID);

            // Refresh the data in the GridView
            BindData();
            Response.Redirect(Request.RawUrl);
        }
        protected void AnnouncementsGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Get the Status field from the data source
                string status = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "Status"));

                // Find the Status cell
                TableCell statusCell = e.Row.Cells[4];

                switch (status)
                {
                    case "Active":
                        statusCell.Text = "✅Active";
                        break;
                }
            }
        }
        protected void AnnouncementsGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}