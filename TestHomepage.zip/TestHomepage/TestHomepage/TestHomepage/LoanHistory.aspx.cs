﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class LoanHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    //int signupID = (int)Session["SignupID"];
                    string username = Session["UserName"].ToString();
                    BindData();
                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);

        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        private void BindData()
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "SELECT Savings, RepaymentID, ApplicantName, LoanID, RepaymentAmount, RepaymentDate, OutstandingBalance FROM LoanRepayments WHERE ApplicantName = @ApplicantName ORDER BY RepaymentDate DESC";

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery, connection);
                dataAdapter.SelectCommand.Parameters.AddWithValue("@ApplicantName", Session["username"].ToString());

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                LoanHistoryGridView.DataSource = dataTable;
                LoanHistoryGridView.DataBind();
            }
        }
        protected void LoanHistoryGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        protected void LoanHistoryGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}