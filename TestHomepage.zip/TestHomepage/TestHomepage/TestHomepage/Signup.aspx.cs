﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;

namespace TestHomepage
{
    public partial class Signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string email = TextBox1.Text;
            string username = TextBox2.Text;
            string password = TextBox3.Text;
            string conpassword = TextBox4.Text;
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                password = builder.ToString();
            }
            // Hash the confirmation password
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(conpassword));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                conpassword = builder.ToString();
            }
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Check if email already exists
                string check = "SELECT * FROM Signup WHERE email = @Email OR username = @Username";
                using (SqlCommand cmd_check = new SqlCommand(check, con))
                {
                    cmd_check.Parameters.AddWithValue("@Email", email);
                    cmd_check.Parameters.AddWithValue("@Username", username);

                    SqlDataReader dr = cmd_check.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Close();
                        Response.Write("<script>alert('Email or username already exists. Please check the entered values')</script>");
                        email = "";
                        username = "";
                        password = "";
                        conpassword = "";
                    }
                    else if (password != conpassword)
                    {
                        dr.Close();
                        Response.Write("<script>alert('Passwords do not match. Please re-enter')</script>");
                        email = "";
                        username = "";
                        password = "";
                        conpassword = "";
                    }
                    else
                    {
                        dr.Close();
                        DateTime date = DateTime.Now;

                        // Insert new user
                        string query = "INSERT INTO Signup (email, username, password, date_created) VALUES (@Email, @Username, @Password, @DateCreated)";
                        using (SqlCommand cmd_insert = new SqlCommand(query, con))
                        {
                            cmd_insert.Parameters.AddWithValue("@Email", email.Trim());
                            cmd_insert.Parameters.AddWithValue("@Username", username.Trim());
                            cmd_insert.Parameters.AddWithValue("@Password", password.Trim());
                            cmd_insert.Parameters.AddWithValue("@DateCreated", date);

                            cmd_insert.ExecuteNonQuery();
                        }

                        string script = "<script>alert('Account created. You can now login'); window.location.href = 'Login.aspx';</script>";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script);
                    }
                }
            }
        }
    }
}