﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class UserAnnouncements : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    //int signupID = (int)Session["SignupID"];
                    string username = Session["UserName"].ToString();
                    BindData();
                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        private void BindData()
        {
            // Define your connection string
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            // Create a new SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                // Create a new SQL command
                using (SqlCommand command = new SqlCommand("SELECT * FROM Announcements", connection))
                {
                    // Execute the command and get the data
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Bind the data to the GridView
                        AnnouncementsGridView.DataSource = reader;
                        AnnouncementsGridView.DataBind();
                    }
                }
            }
        }

        protected void AnnouncementsGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void AnnouncementsGridView_RowDataBound(object sender, EventArgs e)
        {

        }
        
    }
}