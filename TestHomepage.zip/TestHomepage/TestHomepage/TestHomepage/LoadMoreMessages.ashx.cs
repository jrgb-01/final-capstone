﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace TestHomepage
{
    /// <summary>
    /// Summary description for LoadMoreMessages
    /// </summary>
    public class LoadMoreMessages : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            int pageNo = 1;
            if (context.Request.QueryString["page"] != null)
            {
                pageNo = Convert.ToInt32(context.Request.QueryString["page"]);
            }

            string messagesHtml = string.Empty;
            using (SqlConnection conn = new SqlConnection("Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY Timestamp DESC) AS RowNum, * FROM Messages) AS MyDerivedTable WHERE MyDerivedTable.RowNum BETWEEN ((@PageNo - 1) * 30 + 1) AND (@PageNo * 30)", conn))
                {
                    cmd.Parameters.AddWithValue("@PageNo", pageNo);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.HasRows)
                        {
                            context.Response.Write("No more messages");
                            return;
                        }

                        while (reader.Read())
                        {
                            string name = reader["username"].ToString();
                            string message = reader["Message"].ToString();
                            DateTime timestamp = Convert.ToDateTime(reader["Timestamp"]);
                            string timestampStr = "<div class='timestamp'>" + timestamp.ToString("MM/dd/yyyy hh:mm tt") + "</div>";
                            messagesHtml = "<div class='message'>" + timestampStr + "<b>" + name + "</b>: " + message + "</div>" + messagesHtml;
                        }
                    }
                }
            }
            context.Response.Write(messagesHtml);
        }

        public bool IsReusable
        {
            get { return false; }
        }
    }
}