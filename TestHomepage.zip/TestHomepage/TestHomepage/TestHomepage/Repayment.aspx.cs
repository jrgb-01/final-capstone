﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class Repayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    //int signupID = (int)Session["SignupID"];
                    string username = Session["UserName"].ToString();
                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);

        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }

        protected void RepayButton_Click(object sender, EventArgs e)
        {
            string applicantName = Session["username"].ToString();

            string loanId = LoanIDTextBox.Text;
            decimal repaymentAmount = decimal.Parse(RepaymentAmountTextBox.Text);

            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if the loan ID exists and belongs to the current user
                string checkLoanIdQuery = "SELECT COUNT(*) FROM Loans WHERE LoanID = @LoanID AND ApplicantName = @ApplicantName";
                SqlCommand checkLoanIdCommand = new SqlCommand(checkLoanIdQuery, connection);
                checkLoanIdCommand.Parameters.AddWithValue("@LoanID", loanId);
                checkLoanIdCommand.Parameters.AddWithValue("@ApplicantName", applicantName);
                int loanIdExists = (int)checkLoanIdCommand.ExecuteScalar();

                if (loanIdExists == 0)
                {
                    // If the loan ID does not exist or does not belong to the current user, display an error message and return
                    PaymentStatus.Text = "Loan ID does not exist or does not belong to you.";
                    return;
                }

                // Check if the loan is approved
                string checkLoanStatusQuery = "SELECT Status FROM Loans WHERE LoanID = @LoanID";
                SqlCommand checkLoanStatusCommand = new SqlCommand(checkLoanStatusQuery, connection);
                checkLoanStatusCommand.Parameters.AddWithValue("@LoanID", loanId);
                string status = checkLoanStatusCommand.ExecuteScalar().ToString();

                if (status != "Approved")
                {
                    // If the loan is not approved, display an error message and return
                    PaymentStatus.Text = "The loan is not yet approved or it is rejected.";
                    return;
                }

                // Get the current outstanding balance
                string getBalanceQuery = "SELECT OutstandingBalance FROM Loans WHERE LoanID = @LoanID";
                SqlCommand getBalanceCommand = new SqlCommand(getBalanceQuery, connection);
                getBalanceCommand.Parameters.AddWithValue("@LoanID", loanId);
                decimal outstandingBalance = (decimal)getBalanceCommand.ExecuteScalar();

                if (outstandingBalance == 0)
                {
                    // If the outstanding balance is 0, display an error message and return
                    PaymentStatus.Text = "The outstanding balance is already 0. Try other loans.";
                    return;
                }

                if (repaymentAmount > outstandingBalance)
                {
                    // If the repayment amount is greater than the outstanding balance, display an error message and return
                    PaymentStatus.Text = "The repayment amount cannot be greater than the outstanding balance.";
                    return;
                }

                // Get the current savings
                string getSavingsQuery = "SELECT Savings FROM Savings WHERE ApplicantName = @ApplicantName";
                SqlCommand getSavingsCommand = new SqlCommand(getSavingsQuery, connection);
                getSavingsCommand.Parameters.AddWithValue("@ApplicantName", applicantName);
                decimal savings = (decimal)getSavingsCommand.ExecuteScalar();

                if (savings == 0)
                {
                    // If the repayment amount is greater than the savings, display an error message and return
                    PaymentStatus.Text = "You have no more savings in your account. Please deposit to the nearest branch.";
                    return;
                }
                if (repaymentAmount > savings)
                {
                    // If the repayment amount is greater than the savings, display an error message and return
                    PaymentStatus.Text = "The repayment amount cannot be greater than the savings.";
                    return;
                }
                // Calculate the new outstanding balance and the new savings
                decimal newOutstandingBalance = outstandingBalance - repaymentAmount;
                decimal newSavings = savings - repaymentAmount;

                // Update the savings
                string updateSavingsQuery = "UPDATE Savings SET Savings = @NewSavings WHERE ApplicantName = @ApplicantName";
                SqlCommand updateSavingsCommand = new SqlCommand(updateSavingsQuery, connection);
                updateSavingsCommand.Parameters.AddWithValue("@NewSavings", newSavings);
                updateSavingsCommand.Parameters.AddWithValue("@ApplicantName", applicantName);
                updateSavingsCommand.ExecuteNonQuery();

                // Generate a new paymentID
                string repayment = Guid.NewGuid().ToString();

                // Insert a new row into the LoanRepayments table
                string insertRepaymentQuery = "INSERT INTO LoanRepayments (Savings, RepaymentID, ApplicantName, LoanID, RepaymentAmount, RepaymentDate, OutstandingBalance) VALUES (@Savings, @RepaymentID, @ApplicantName, @LoanID, @RepaymentAmount, @RepaymentDate, @OutstandingBalance)";
                SqlCommand insertRepaymentCommand = new SqlCommand(insertRepaymentQuery, connection);
                insertRepaymentCommand.Parameters.AddWithValue("@Savings", newSavings);
                insertRepaymentCommand.Parameters.AddWithValue("@RepaymentID", repayment);
                insertRepaymentCommand.Parameters.AddWithValue("@ApplicantName", applicantName);
                insertRepaymentCommand.Parameters.AddWithValue("@LoanID", loanId);
                insertRepaymentCommand.Parameters.AddWithValue("@RepaymentAmount", repaymentAmount);
                insertRepaymentCommand.Parameters.AddWithValue("@RepaymentDate", DateTime.Now);
                insertRepaymentCommand.Parameters.AddWithValue("@OutstandingBalance", newOutstandingBalance);
                insertRepaymentCommand.ExecuteNonQuery();

                // Update the outstanding balance, repayment amount, and repayment date in the Loans table
                string updateLoanQuery = "UPDATE Loans SET OutstandingBalance = @OutstandingBalance, RepaymentAmount = @RepaymentAmount, RepaymentDate = @RepaymentDate WHERE LoanID = @LoanID";
                SqlCommand updateLoanCommand = new SqlCommand(updateLoanQuery, connection);
                updateLoanCommand.Parameters.AddWithValue("@LoanID", loanId);
                updateLoanCommand.Parameters.AddWithValue("@OutstandingBalance", newOutstandingBalance);
                updateLoanCommand.Parameters.AddWithValue("@RepaymentAmount", repaymentAmount);
                updateLoanCommand.Parameters.AddWithValue("@RepaymentDate", DateTime.Now);
                updateLoanCommand.ExecuteNonQuery();

                // Display a success message
                PaymentStatus.Text = "Payment processed successfully.";
            }
        }
    }
}