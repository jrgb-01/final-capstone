﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Services;

namespace TestHomepage
{
    public partial class Messaging : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] != null)
            {
                ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

                // Get the username from the session
                string username = Session["UserName"].ToString();

                // Set the Text property of the txtName TextBox to the username
                txtName.Text = username;
                // Disable the txtName TextBox
                txtName.Enabled = false;

                // Load the initial messages when the page loads for the first time
                if (!IsPostBack)
                {
                    LoadMessages(1);
                }
            }
            else
            {
                // Redirect to login page if the user is not logged in
                Response.Redirect("Login.aspx");
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }

        private void LoadMessages(int pageNo)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY Timestamp DESC) AS RowNum, * FROM Messages) AS MyDerivedTable WHERE MyDerivedTable.RowNum BETWEEN ((@PageNo - 1) * 30 + 1) AND (@PageNo * 30)", conn))
                {
                    cmd.Parameters.AddWithValue("@PageNo", pageNo);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        divMessages.InnerHtml = string.Empty;
                        while (reader.Read())
                        {
                            string name = reader["username"].ToString();
                            string message = reader["Message"].ToString();
                            DateTime timestamp = Convert.ToDateTime(reader["Timestamp"]);
                            string timestampStr = "<div class='timestamp'>" + timestamp.ToString("MM/dd/yyyy hh:mm tt") + "</div>";
                            divMessages.InnerHtml = "<div class='message'>" + timestampStr + "<b>" + name + "</b>: " + message + "</div>" + divMessages.InnerHtml;
                        }
                    }
                }
            }
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            // Check if the user is an admin
            if (Session["username"].ToString() == "admin")
            {
                Session.Abandon();
                // Redirect to the admin login page
                Response.Redirect("AdminLogin.aspx");
            }
            else
            {
                Session.Abandon();
                // Redirect to the member login page
                Response.Redirect("Login.aspx");
            }
        }
        protected void btnSend_Click(object sender, EventArgs e)
        {
            // Get the username from the session
            string username = Session["username"].ToString();

            // Trim the TextBoxes and check if they are empty
            string message = txtMessage.Text.Trim();
            if (string.IsNullOrWhiteSpace(message))
            {
                return;
            }
            // Get current date and time without seconds
            DateTime now = DateTime.Now;
            string timestamp = now.ToString("MM/dd/yyyy hh:mm tt");

            // Add new message to div box
            var messages = Application["Messages"] as string[] ?? new string[0];
            var newMessages = new string[messages.Length + 1];
            messages.CopyTo(newMessages, 0);
            newMessages[newMessages.Length - 1] = timestamp + "<b>" + username + "</b>: " + message;
            Application["Messages"] = newMessages;

            // Insert message into database
            using (SqlConnection conn = new SqlConnection("Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Messages (username, Message, Timestamp) VALUES (@Username, @Message, @Timestamp)", conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Message", message);
                    cmd.Parameters.AddWithValue("@Timestamp", now);
                    cmd.ExecuteNonQuery();
                }
            }

            // Refresh messages
            Page_Load(sender, e);
            // Redirect to the same page
            Response.Redirect(Request.RawUrl);
        }
    }
}
