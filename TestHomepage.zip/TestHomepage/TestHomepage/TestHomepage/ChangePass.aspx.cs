﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Web.SessionState;

namespace TestHomepage
{
    public partial class ForgotPassYari : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["username"] != null)
            {
                ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
                //int signupID = (int)Session["SignupID"];
                string username = Session["UserName"].ToString();
            }
            else
            {
                // Redirect to login page if the user is not logged in
                Response.Redirect("Login.aspx");
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string OldPass = txtCurrentPass.Text;
            string NewPass = txtNewPass.Text;
            string ConfirmPass = txtConfirmPass.Text;
            // Hash the old password
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(OldPass));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                OldPass = builder.ToString();
            }
            // Hash the new password
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(NewPass));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                NewPass = builder.ToString();
            }
            // Hash the confirmation password
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(ConfirmPass));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                ConfirmPass = builder.ToString();
            }
            // Retrieve the username from the session
            string username = Session["username"].ToString();
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Check if the current password is correct
                string check = "SELECT password FROM Signup WHERE username = @Username";
                using (SqlCommand cmd_check = new SqlCommand(check, con))
                {
                    cmd_check.Parameters.AddWithValue("@Username", username);

                    string currentPassword = cmd_check.ExecuteScalar() as string;
                    if (OldPass == NewPass)
                    {
                        // New password is the same as the old password
                        Response.Write("<script>alert('New password must be different from the old password')</script>");
                        OldPass = "";
                        NewPass = "";
                        ConfirmPass = "";
                        return;
                    }
                    if (currentPassword != OldPass)
                    {
                        Response.Write("<script>alert('Current Password is incorrect. Please try again')</script>");
                        OldPass = "";
                        NewPass = "";
                        ConfirmPass = "";
                        return;
                    }
                    else if (NewPass != ConfirmPass)
                    {
                        Response.Write("<script>alert('Passwords do not match. Please re-enter')</script>");
                        OldPass = "";
                        NewPass = "";
                        ConfirmPass = "";
                        return;
                    }
                    else
                    {
                        // Update password
                        string query = "UPDATE Signup SET password = @NewPassword WHERE username = @Username";
                        using (SqlCommand cmd_update = new SqlCommand(query, con))
                        {
                            cmd_update.Parameters.AddWithValue("@Username", username.Trim());
                            cmd_update.Parameters.AddWithValue("@NewPassword", NewPass.Trim());

                            int rowsAffected = cmd_update.ExecuteNonQuery();

                            if (rowsAffected == 1)
                            {
                                // Password update was successful
                                string script = "<script>alert('Password has been updated successfully'); window.location.href = 'Membership.aspx';</script>";
                                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script);
                            }
                            else
                            {
                                // Password update failed
                                string script = "<script>alert('Password update failed. Please try again')</script>";
                                ClientScript.RegisterStartupScript(this.GetType(), "FailureMessage", script);
                            }
                        }
                    }
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Membership.aspx");
        }
    }
}