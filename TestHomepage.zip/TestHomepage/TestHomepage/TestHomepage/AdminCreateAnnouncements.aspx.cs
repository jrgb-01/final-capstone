﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

namespace TestHomepage
{
    public partial class AdminCreateAnnouncements : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    // Use the signupId to fetch membership information
                    //BindingData();
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }

        protected void InsertButton_Click(object sender, EventArgs e)
        {
            // Generate a random announcement ID
            Random random = new Random();
            int announcementID = random.Next(1000, 9999); // Adjust range as needed

            // Get the current date and time
            DateTime dateCreated = DateTime.Now;

            // Set the status to "Active"
            string status = "Active";

            // Get the title and content from the form
            string title = AnnouncementTitle.Text;
            string content = Content.Text;

            // Get the uploaded file
            HttpPostedFile postedFile = ImageUpload.PostedFile;
            string imageUrl = "";

            // Check if a file is uploaded
            if (postedFile != null && postedFile.ContentLength > 0)
            {
                // Get the file extension
                string fileExtension = Path.GetExtension(postedFile.FileName).ToLower();

                // Validate the file extension
                if (fileExtension == ".jpg" || fileExtension == ".png")
                {
                    // Check the MIME type to ensure it's an image
                    string mimeType = postedFile.ContentType;
                    if (mimeType == "image/jpeg" || mimeType == "image/png")
                    {
                        // Save the file to your server or CDN
                        string filePath = "~/Images/" + Path.GetFileName(postedFile.FileName);
                        postedFile.SaveAs(Server.MapPath(filePath));

                        // Get the URL of the uploaded image
                        imageUrl = Request.Url.GetLeftPart(UriPartial.Authority) + VirtualPathUtility.ToAbsolute(filePath);
                    }
                    else
                    {
                        // Update the status message
                        StatusMessage.Text = "Invalid file format. Please upload a .jpg or .png image.";
                        return;
                    }
                }
                else
                {
                    // Update the status message
                    StatusMessage.Text = "Invalid file format. Please upload a .jpg or .png image.";
                    return;
                }
            }

            // Define your connection string
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            // Create a new SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                // Create a new SQL command
                using (SqlCommand command = new SqlCommand("INSERT INTO Announcements (AnnouncementID, Title, Content, ImageUrl, Status, DateCreated) VALUES (@AnnouncementID, @Title, @Content, @ImageUrl, @Status, @DateCreated)", connection))
                {
                    // Add the parameters
                    command.Parameters.AddWithValue("@AnnouncementID", announcementID);
                    command.Parameters.AddWithValue("@Title", title);
                    command.Parameters.AddWithValue("@Content", content);
                    command.Parameters.AddWithValue("@ImageUrl", imageUrl);
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@DateCreated", dateCreated);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }
            StatusMessage.Text = "Announcement successfully inserted.";

        }
    }
}