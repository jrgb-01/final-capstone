﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class ForgotPass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string username = txtConfirmEmail.Text;
            string email = txtConfirmEmail.Text;

            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string check = "SELECT * FROM Signup WHERE username = @Username OR email = @Email";
                using (SqlCommand cmd_check = new SqlCommand(check, con))
                {
                    cmd_check.Parameters.AddWithValue("@Username", username);
                    cmd_check.Parameters.AddWithValue("@Email", email);

                    SqlDataReader dr = cmd_check.ExecuteReader();

                    if (dr.HasRows)
                    {
                        Session["username"] = username;
                        string script = "<script>alert('We found your record. You can now proceed'); window.location.href = 'ResetPass.aspx';</script>";
                        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script);
                    }
                    else
                    {
                        // Handle the case where the email or username does not exist in the database
                        Response.Write("<script>alert('Email or username does not exist. Please check your input or registration')</script>");
                    }
                }
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }


    }
}