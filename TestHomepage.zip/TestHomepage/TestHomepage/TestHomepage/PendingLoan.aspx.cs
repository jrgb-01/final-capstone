﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace TestHomepage
{
    public partial class PendingLoan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    BindData();

                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }
        private void BindData()
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "SELECT Savings, LoanID, ApplicantName, LoanType, LoanAmount, LoanTerm, LoanPurpose, Status, IsProcessed, DateSubmitted, OutstandingBalance, RepaymentAmount, RepaymentDate FROM Loans ORDER BY DateSubmitted DESC";

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery, connection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                PendingLoansGridView.DataSource = dataTable;
                PendingLoansGridView.DataBind();
            }
        }
        private void UpdateLoanStatus(string loanId, string status, decimal loanAmount)
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "UPDATE Loans SET Status = @Status, IsProcessed = 1 WHERE LoanID = @LoanID";

                if (status == "Approved")
                {
                    // If the loan is approved, set the OutstandingBalance to the LoanAmount, calculate the NextPaymentDate, and set the DateApproved
                    sqlQuery = "UPDATE Loans SET Status = @Status, IsProcessed = 1, OutstandingBalance = @OutstandingBalance, NextPaymentDate = @NextPaymentDate, DateApproved = @DateApproved WHERE LoanID = @LoanID";
                }

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.Parameters.AddWithValue("@LoanID", loanId);
                    command.Parameters.AddWithValue("@Status", status);

                    if (status == "Approved")
                    {
                        // If the loan is approved, set the OutstandingBalance to the LoanAmount, calculate the NextPaymentDate, and set the DateApproved
                        command.Parameters.AddWithValue("@OutstandingBalance", loanAmount);
                        command.Parameters.AddWithValue("@NextPaymentDate", DateTime.Now.AddMonths(1));
                        command.Parameters.AddWithValue("@DateApproved", DateTime.Now);
                    }

                    command.ExecuteNonQuery();
                }
            }
        }


        private void UpdateLoanStatusWithReason(string loanId, string status, string reason)
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "UPDATE Loans SET Status = @Status, ReasonForDisapproval = @Reason, IsProcessed = 1 WHERE LoanID = @LoanID";

                if (status == "Rejected")
                {
                    // If the loan is rejected, set the DateRejected
                    sqlQuery = "UPDATE Loans SET Status = @Status, ReasonForDisapproval = @Reason, IsProcessed = 1, DateRejected = @DateRejected WHERE LoanID = @LoanID";
                }

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.Parameters.AddWithValue("@LoanID", loanId);
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@Reason", reason);

                    if (status == "Rejected")
                    {
                        // If the loan is rejected, set the DateRejected
                        command.Parameters.AddWithValue("@DateRejected", DateTime.Now);
                    }

                    command.ExecuteNonQuery();
                }
            }
        }
        protected void ApproveButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string loanId = btn.CommandArgument;

            // Get the GridViewRow that contains the clicked button
            GridViewRow row = (GridViewRow)btn.NamingContainer;

            // Find the LoanAmount cell in the row and get its value
            TableCell loanAmountCell = row.Cells[4];
            decimal loanAmount = decimal.Parse(loanAmountCell.Text);

            // Call your method to update the loan status to "Approved"
            UpdateLoanStatus(loanId, "Approved", loanAmount);

            // Rebind the GridView to reflect the changes
            PendingLoansGridView.DataBind();
            BindData();
            Response.Redirect(Request.RawUrl);
        }

        protected void RejectButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string loanId = btn.CommandArgument;

            // Get the reject reason from the TextBox in the same GridView row
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            TextBox txtRejectReason = (TextBox)row.FindControl("RejectReason");
            string rejectReason = txtRejectReason.Text;
            if (string.IsNullOrWhiteSpace(rejectReason))
            {
                // Find the Label control in the row
                Label errorMessageLabel = (Label)row.FindControl("ErrorMessageLabel");

                // Display an error message
                errorMessageLabel.Text = "Reason cannot be empty.";
                return;
            }
            // Call your method to update the loan status to "Rejected" and save the reject reason
            UpdateLoanStatusWithReason(loanId, "Rejected", rejectReason);

            // Rebind the GridView to reflect the changes
            PendingLoansGridView.DataBind();
            BindData();
            Response.Redirect(Request.RawUrl);

        }
        protected void PendingLoansGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Get the IsProcessed field from the data source
                bool isProcessed = Convert.ToBoolean(DataBinder.Eval(e.Row.DataItem, "IsProcessed"));

                if (isProcessed)
                {
                    // Find the buttons and disable them
                    Button approveButton = (Button)e.Row.FindControl("ApproveButton");
                    Button rejectButton = (Button)e.Row.FindControl("RejectButton");
                    TextBox rejectReason = (TextBox)e.Row.FindControl("RejectReason");

                    approveButton.Enabled = false;
                    rejectButton.Enabled = false;
                    rejectReason.Enabled = false;
                }
                // Get the Status field from the data source
                string status = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "Status"));

                // Find the Status cell
                TableCell statusCell = e.Row.Cells[7];

                switch (status)
                {
                    case "Pending":
                        statusCell.Text = "🟡Pending";
                        break;
                    case "Approved":
                        statusCell.Text = "✅Approved";
                        break;
                    case "Rejected":
                        statusCell.Text = "❌Rejected";
                        break;
                }
            }
        }

        protected void PendingLoansGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}