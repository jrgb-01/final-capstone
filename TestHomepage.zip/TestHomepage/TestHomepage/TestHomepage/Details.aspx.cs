﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the announcement ID from the URL
                    int announcementId = Convert.ToInt32(Request.QueryString["id"]);

                    // Use the announcement ID to fetch announcement information
                    using (SqlConnection conn = new SqlConnection("Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True"))
                    {
                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("SELECT * FROM Announcements WHERE AnnouncementID = @id", conn))
                        {
                            cmd.Parameters.AddWithValue("@id", announcementId);
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    ImageView.ImageUrl = reader["ImageUrl"].ToString(); // Set the ImageUrl property of the Image control
                                    TitleLabel.Text = "<b>Title:</b> <br />" + HttpUtility.HtmlEncode(reader["Title"].ToString()) + "<br />";
                                    ContentLabel.Text = "<b>Content:</b> <br />" + HttpUtility.HtmlEncode(reader["Content"].ToString()) + "<br />";
                                    DateCreatedLabel.Text = "<b>Date Created:</b> <br />" + HttpUtility.HtmlEncode(reader["DateCreated"].ToString()) + "<br />";
                                    DateUpdatedLabel.Text = "<b>Date Updated:</b> <br />" + HttpUtility.HtmlEncode(reader["DateUpdated"].ToString()) + "<br />";
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }
    }
}