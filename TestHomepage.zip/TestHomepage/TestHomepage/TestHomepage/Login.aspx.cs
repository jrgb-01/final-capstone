﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;

namespace TestHomepage
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string email = TextBox1.Text;
            string username = TextBox1.Text;
            string password = TextBox2.Text;
            // Hash the entered password
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                password = builder.ToString();
            }
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string check = "SELECT * FROM Signup WHERE username = @Username OR email = @Email";
                using (SqlCommand cmd_check = new SqlCommand(check, con))
                {
                    cmd_check.Parameters.AddWithValue("@Username", username);
                    cmd_check.Parameters.AddWithValue("@Email", email);
                    cmd_check.Parameters.AddWithValue("@Password", password);

                    SqlDataReader dr = cmd_check.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        if (dr["password"].ToString() != password)
                        {
                            dr.Close();
                            Response.Write("<script>alert('Wrong Password')</script>");
                            username = "";
                            password = "";
                        }
                        else
                        {
                            dr.Close();  // Close the DataReader here

                            // Get the signupId from the database
                            string getSignupIdQuery = "SELECT signup_id FROM Signup WHERE username = @Username OR email = @Email";
                            using (SqlCommand cmdGetSignupId = new SqlCommand(getSignupIdQuery, con))
                            {
                                cmdGetSignupId.Parameters.AddWithValue("@Username", username);
                                cmdGetSignupId.Parameters.AddWithValue("@Email", email);
                                int signupId = (int)cmdGetSignupId.ExecuteScalar();

                                // Set the username and signupId in the session
                                Session["username"] = username;
                                Session["signupId"] = signupId;
                            }

                            Response.Redirect("Membership.aspx");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Username/Email is incorrect or does not exist')</script>");
                        username = "";
                        password = "";
                    }
                }
            }
        }
    }
}