﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.SessionState;


namespace TestHomepage
{
    public partial class MemberInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["signupId"] != null && Session["username"] != null)
                {
                    // Retrieve the signupId and username from the session
                    int signupId = Convert.ToInt32(Session["signupId"]);
                    string username = Session["username"].ToString();

                    // Use the signupId and username to fetch membership information
                    Populate(signupId, username);
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }

        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        void Populate(int signupId, string username)
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string sqlQuery = @"
                SELECT M.firstname, M.lastname, M.contactno, M.sex, M.address, M.membershipno, M.status, M.idno, M.assignment
                FROM Membership M
                JOIN Signup S ON M.signup_id = S.signup_id
                WHERE M.signup_id = @signupId";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.Parameters.AddWithValue("@signupId", signupId);

                    // Execute the SQL command and get the result
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                TextBox1.Text = GetValueFromReader(reader, "firstname") + " " + GetValueFromReader(reader, "lastname");
                                TextBox2.Text = GetValueFromReader(reader, "contactno");
                                TextBox3.Text = GetValueFromReader(reader, "sex");
                                TextBox4.Text = GetValueFromReader(reader, "address");
                                TextBox5.Text = GetValueFromReader(reader, "membershipno");
                                TextBox6.Text = GetValueFromReader(reader, "status");
                                TextBox7.Text = GetValueFromReader(reader, "idno");
                                TextBox8.Text = GetValueFromReader(reader, "assignment");
                                TextBox9.Text = GetValueFromReader(reader, "membershipno");
                            }
                        }
                        else
                        {
                            // Handle the case where no data is found
                            TextBox1.Text = "No data found.";
                            TextBox2.Text = "No data found.";
                            TextBox3.Text = "No data found.";
                            TextBox4.Text = "No data found.";
                            TextBox5.Text = "No data found.";
                            TextBox6.Text = "No data found.";
                            TextBox7.Text = "No data found.";
                            TextBox8.Text = "No data found.";
                            TextBox9.Text = "No data found.";
                        }

                        reader.Close();

                    // Get the savings
                    string getSavingsQuery = "SELECT Savings FROM Savings WHERE ApplicantName = @Username";
                    SqlCommand getSavingsCommand = new SqlCommand(getSavingsQuery, connection);
                    getSavingsCommand.Parameters.AddWithValue("@Username", username);

                    object result = getSavingsCommand.ExecuteScalar();
                    decimal savings = result != DBNull.Value ? Convert.ToDecimal(result) : 0;

                    // Set the savings as the Text property of the TextBox
                    savingsText.Text = savings.ToString("N2");
                    }
                }
            }
        }

        private string GetValueFromReader(SqlDataReader reader, string columnName)
        {
            object value = reader[columnName];
            return value != null && value != DBNull.Value ? value.ToString() : "No data found.";
        }

        protected void TextBox10_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
