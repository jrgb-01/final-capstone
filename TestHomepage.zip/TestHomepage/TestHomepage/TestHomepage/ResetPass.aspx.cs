﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.SessionState;
using System.Security.Cryptography;
using System.Text;

namespace TestHomepage
{
    public partial class ResetPass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] != null)
            {
                ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
                //int signupID = (int)Session["SignupID"];
                string username = Session["UserName"].ToString();
            }
            else
            {
                // Redirect to search account
                Response.Redirect("EmailVerify.aspx");
            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            {
                string NewPass = txtNewPass.Text;
                string ConfirmPass = txtConfirmPass.Text;
                // Hash the new password
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(NewPass));
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }
                    NewPass = builder.ToString();
                }
                // Hash the confirmation password
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(ConfirmPass));
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }
                    ConfirmPass = builder.ToString();
                }
                // Retrieve the email or username from the session
                string username = Session["username"].ToString();
                string email = Session["username"].ToString();

                string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    if (NewPass != ConfirmPass)
                    {
                        Response.Write("<script>alert('Passwords do not match. Please re-enter')</script>");
                        NewPass = "";
                        ConfirmPass = "";
                        return;
                    }
                    else
                        {
                        // reset password
                        string query = "UPDATE Signup SET password = @NewPassword WHERE username = @Username or email = @Email";
                        using (SqlCommand cmd_update = new SqlCommand(query, con))
                        {
                            cmd_update.Parameters.AddWithValue("@Username", username.Trim());
                            cmd_update.Parameters.AddWithValue("@Email", email.Trim());
                            cmd_update.Parameters.AddWithValue("@NewPassword", NewPass.Trim());

                            int rowsAffected = cmd_update.ExecuteNonQuery();

                            if (rowsAffected == 1)
                            {
                                // Password reset was successful
                                string script = "<script>alert('Password has been reset successfully'); window.location.href = 'Login.aspx';</script>";
                                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script);
                            }
                            else
                            {
                                // Password reset failed
                                string script = "<script>alert('Password reset failed. Please try again')</script>";
                                ClientScript.RegisterStartupScript(this.GetType(), "FailureMessage", script);
                            }
                        
                        }
                    }
                }

            }
        }
    }
}
