﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestHomepage
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string username = TextBox1.Text;
            string password = TextBox2.Text;

            int AdminId;

            if (ValidateUser(username, password, out AdminId))
            {
                // Store signupId and username in the session
                Session["AdminId"] = AdminId;
                Session["username"] = username;

                Response.Redirect($"AdminDashboard.aspx?AdminId={AdminId}");
            }
            else
            {
                Response.Write("<script>alert('Username or password is incorrect')</script>");
            }
        }
        private bool ValidateUser(string username, string password, out int signupId)
        {
            signupId = 0;

            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Retrieve signup_id and username from the database
                string check = "SELECT admin_id FROM LoginAdmin WHERE username = @Username AND password = @Password";

                using (SqlCommand cmd_check = new SqlCommand(check, con))
                {
                    cmd_check.Parameters.AddWithValue("@Username", username);
                    cmd_check.Parameters.AddWithValue("@Password", password);

                    object result = cmd_check.ExecuteScalar();

                    if (result != null)
                    {
                        signupId = Convert.ToInt32(result);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
    }
}