﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace TestHomepage
{
    public partial class AdminApprovedLoans : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    BindData();

                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }
        private void BindData()
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "SELECT LoanID, ApplicantName, LoanType, LoanAmount, LoanTerm, LoanPurpose, Status, DateSubmitted, DateApproved, OutstandingBalance, NextPaymentDate FROM Loans WHERE Status = 'Approved' ORDER BY DateApproved DESC";

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery, connection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                CurrentLoanGridView.DataSource = dataTable;
                CurrentLoanGridView.DataBind();
            }
        }
        protected void CurrentLoanGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Get the Status field from the data source
                string status = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "Status"));

                // Find the Status cell
                TableCell statusCell = e.Row.Cells[6];

                switch (status)
                {
                    case "Approved":
                        statusCell.Text = "✅Approved";
                        break;
                }
            }
        }
        protected void CurrentLoanGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}