﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.SessionState;


namespace TestHomepage
{
    public partial class Membership : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["signupId"] != null)
            {
                int signupID = (int)Session["signupId"];
                // You can use signupID as needed
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);

        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string membershipnum = Request.Form["MembershipNumber"];
            string bodreso = Request.Form["BODResolutionNumber"];
            string idno = Request.Form["IDNumber"];
            string lastname = Request.Form["LastName"];
            string firstname = Request.Form["FirstName"];
            string middlename = Request.Form["MiddleName"];
            string address = Request.Form["PresentAddress"];
            string contactno = Request.Form["ContactNumber"];
            string civilstatus = Request.Form["CivilStatus"];
            string sex = Request.Form["SelectGender"];
            string birthdate = Request.Form["DateOfBirth"];
            string age = Request.Form["Age"];
            string assignment = Request.Form["Assignment"];
            string refname = Request.Form["name-7"];
            string refaddress = Request.Form["email-4"];
            string refcontactno = Request.Form["name-3"];
            int signupID = (int)Session["signupId"];
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            if (captchacode.Text.ToLower() == Session["sessionCaptcha"].ToString())
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    // Check if the user has already registered in the Membership table
                    string checkQuery = "SELECT * FROM Membership WHERE signup_id = @SignupID";
                    using (SqlCommand cmdCheck = new SqlCommand(checkQuery, con))
                    {
                        cmdCheck.Parameters.AddWithValue("@SignupID", signupID);
                        using (SqlDataReader dr = cmdCheck.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                // User has already registered in Membership table
                                Response.Write("<script>alert('You have already submitted a Membership Form. Please wait for the admin to review it.')</script>");
                                return;
                            }
                        }
                    }
                    // Check if the membership record already exists
                    string checkMembershipQuery = "SELECT * FROM Membership WHERE membershipno = @MembershipNo AND bodresono = @BODResoNo AND idno = @IDNo";
                    using (SqlCommand cmdCheckMembership = new SqlCommand(checkMembershipQuery, con))
                    {
                        cmdCheckMembership.Parameters.AddWithValue("@MembershipNo", membershipnum);
                        cmdCheckMembership.Parameters.AddWithValue("@BODResoNo", bodreso);
                        cmdCheckMembership.Parameters.AddWithValue("@IDNo", idno);
                        using (SqlDataReader dr = cmdCheckMembership.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                // Membership record already exists
                                Response.Write("<script>alert('Membership, BOD Resolution, or Id Number already exists. Please check the entered values')</script>");
                                return;
                            }
                        }
                    }
                    // Insert into Membership table
                    string insertQuery = @"
            INSERT INTO Membership (
            membershipno, bodresono, idno, lastname, firstname, middlename, 
            address, contactno, civilstatus, sex, dateofbirth, age, assignment, 
            refname, refaddress, refcontactno, signup_id, status
            ) 
            VALUES (
            @MembershipNo, @BODResoNo, @IDNo, @LastName, @FirstName, @MiddleName, 
            @Address, @ContactNo, @CivilStatus, @Sex, @DateOfBirth, @Age, @Assignment, 
            @RefName, @RefAddress, @RefContactNo, @SignupID, 'Pending'
            )";
                    using (SqlCommand cmdInsert = new SqlCommand(insertQuery, con))
                    {
                        cmdInsert.Parameters.AddWithValue("@MembershipNo", membershipnum);
                        cmdInsert.Parameters.AddWithValue("@BODResoNo", bodreso);
                        cmdInsert.Parameters.AddWithValue("@IDNo", idno);
                        cmdInsert.Parameters.AddWithValue("@LastName", lastname);
                        cmdInsert.Parameters.AddWithValue("@FirstName", firstname);
                        cmdInsert.Parameters.AddWithValue("@MiddleName", middlename);
                        cmdInsert.Parameters.AddWithValue("@Address", address);
                        cmdInsert.Parameters.AddWithValue("@ContactNo", contactno);
                        cmdInsert.Parameters.AddWithValue("@CivilStatus", civilstatus);
                        cmdInsert.Parameters.AddWithValue("@Sex", sex);
                        cmdInsert.Parameters.AddWithValue("@DateOfBirth", birthdate);
                        cmdInsert.Parameters.AddWithValue("@Age", age);
                        cmdInsert.Parameters.AddWithValue("@Assignment", assignment);
                        cmdInsert.Parameters.AddWithValue("@RefName", refname);
                        cmdInsert.Parameters.AddWithValue("@RefAddress", refaddress);
                        cmdInsert.Parameters.AddWithValue("@RefContactNo", refcontactno);
                        cmdInsert.Parameters.AddWithValue("@SignupID", signupID);
                        cmdInsert.ExecuteNonQuery();
                    }
                }
                Response.Write("<script>alert('Form Submitted')</script>");
            }
            else
            {
                lblErrorMsg.Text = "Input again the given characters";
                lblErrorMsg.ForeColor = System.Drawing.Color.Red;
                Response.Write("<script>alert('Captcha is incorrect. Please try again')</script>");
            }
        }

    }
}
