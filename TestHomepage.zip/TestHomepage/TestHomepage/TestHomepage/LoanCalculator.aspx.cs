﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestHomepage
{
    public partial class LoanCalculator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    //int signupID = (int)Session["SignupID"];
                    string username = Session["UserName"].ToString();
                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);

        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }

        protected void CalculateButton_Click(object sender, EventArgs e)
        {
            // Get the loan amount, loan term, and interest rate from the text boxes
            decimal loanAmount = decimal.Parse(LoanAmountTextBox.Text);
            int loanTerm = int.Parse(LoanTermTextBox.Text); // Loan term in months
            decimal interestRate = decimal.Parse(InterestRateTextBox.Text) / 100; // Convert interest rate to decimal

            if (loanAmount < 5000)
            {
                // Display an error message and return
                TextBox1.Text = "Error: The loan amount must be at least 5000.";
                TotalAmountPaidTextBox.Text = "Error: The loan amount must be at least 5000.";
                FutureLoanAmountTextBox.Text = "Error: The loan amount must be at least 5000.";

                return;
            }
            if (loanTerm < 3) // Check loan term in months
            {
                // Display an error message and return
                TextBox1.Text = "Error: The loan term must be a minimum of 3 months.";
                TotalAmountPaidTextBox.Text = "Error: The loan term must be a minimum of 3 months.";
                FutureLoanAmountTextBox.Text = "Error: The loan term must be a minimum of 3 months.";

                return;
            }
            if (loanTerm < 12) // If loan term is less than a year
            {
                interestRate = 0; // Set interest rate to 0
            }
            else if (interestRate < 0.06m) // Check interest rate in decimal
            {
                // Display an error message and return
                TextBox1.Text = "Error: The interest rate must be at least 6%.";
                TotalAmountPaidTextBox.Text = "Error: The interest rate must be at least 6%.";
                FutureLoanAmountTextBox.Text = "Error: The interest rate must be at least 6%.";

                return;
            }

            // Calculate the monthly interest rate
            decimal monthlyInterestRate = interestRate / 12;

            // Calculate the number of payments
            int numberOfPayments = loanTerm;

            // Calculate the monthly payment
            decimal monthlyPayment;
            if (monthlyInterestRate > 0)
            {
                monthlyPayment = (loanAmount * monthlyInterestRate) / (1 - (decimal)Math.Pow(1 + (double)monthlyInterestRate, -numberOfPayments));
            }
            else
            {
                monthlyPayment = loanAmount / numberOfPayments;
            }

            // Display the monthly payment in the text box
            TextBox1.Text = monthlyPayment.ToString("F2");

            // Calculate the total amount paid over the term of the loan
            decimal totalAmountPaid = monthlyPayment * numberOfPayments;

            // Display the total amount paid in the text box
            TotalAmountPaidTextBox.Text = totalAmountPaid.ToString("F2");

            // Calculate the future loan amount
            decimal futureLoanAmount = loanAmount + (loanAmount * interestRate * (loanTerm / 12m));

            // Display the future loan amount in the text box
            FutureLoanAmountTextBox.Text = futureLoanAmount.ToString("F2");
        }

    }
}