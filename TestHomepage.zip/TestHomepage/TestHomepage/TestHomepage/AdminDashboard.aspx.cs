﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestHomepage
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    // Use the signupId to fetch membership information
                    //BindingData();
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);
        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("AdminLogin.aspx");
        }
        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[2].Text = "Membership Number";
                e.Row.Cells[3].Text = "BOD Resolution Number";
                e.Row.Cells[4].Text = "ID Number";
                e.Row.Cells[5].Text = "Name";
                e.Row.Cells[6].Text = "Address";
                e.Row.Cells[7].Text = "Contact Number";
                e.Row.Cells[8].Text = "Sex";
                e.Row.Cells[9].Text = "Birthdate";
                e.Row.Cells[10].Text = "Age";
                e.Row.Cells[11].Text = "Assignment";
                e.Row.Cells[12].Text = "Referral Name";
                e.Row.Cells[13].Text = "Referral Address";
                e.Row.Cells[14].Text = "Referral Contact Number";
                e.Row.Cells[15].Text = "Status";

            }
        }
    }
}