﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace TestHomepage
{
    public partial class MembershipApproval : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if the user is logged in
                if (Session["AdminId"] != null)
                {
                    // Retrieve the signupId from the session
                    int AdminId = Convert.ToInt32(Session["AdminId"]);

                    // Use the signupId to fetch membership information
                    BindingData();
                }
                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("AdminLogin.aspx");
                }
            }
        }
        void BindingData()
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                DataTable dt = new DataTable();
                string select = "SELECT membershipno, bodresono, idno, CONCAT(firstname, ' ', middlename, ' ', lastname) AS full_name, address, contactno, sex, CONVERT(VARCHAR, dateofbirth, 101) AS dateofbirth, age, assignment, refname, refaddress, refcontactno, status FROM Membership WHERE status = 'Pending';";

                using (SqlDataAdapter da = new SqlDataAdapter(select, con))
                {
                    da.Fill(dt);
                }
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    // Clear existing data and display a message
                    GridView1.DataSource = null;
                    GridView1.DataBind();

                    // Check if there are any rows before trying to manipulate them
                    if (GridView1.Rows.Count > 0)
                    {
                        int columnCount = GridView1.Rows[0].Cells.Count;
                        GridView1.Rows[0].Cells.Clear();
                        GridView1.Rows[0].Cells.Add(new TableCell());
                        GridView1.Rows[0].Cells[0].ColumnSpan = columnCount;
                        GridView1.Rows[0].Cells[0].Text = "No pending membership applicants.";
                    }
                }
                con.Close();
            }
        }

        private void UpdateApprove(string membershipNo, string date)
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sqlQuery = "UPDATE Membership SET status = 'Approved' WHERE membershipno = @membershipNo";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.Parameters.AddWithValue("@membershipNo", membershipNo);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void UpdateReject(string membershipNo, string date)
        {
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = "UPDATE Membership SET status = 'Rejected' WHERE membershipno = @membershipNo";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@membershipNo", membershipNo);

                    cmd.ExecuteNonQuery();
                }

                con.Close();
            }
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve" || e.CommandName == "Reject")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];

                // Assuming that the membershipno is stored in the third cell of the row
                string membershipNo = row.Cells[2].Text;

                if (e.CommandName == "Approve")
                {
                    UpdateApprove(membershipNo, DateTime.Now.ToString());
                    BindingData();
                }
                else if (e.CommandName == "Reject")
                {
                    UpdateReject(membershipNo, DateTime.Now.ToString());
                    BindingData();
                }
            }
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Assuming that the status is stored in the 16th cell of the row
                TableCell statusCell = e.Row.Cells[15];
                string status = statusCell.Text;

                switch (status)
                {
                    case "Pending":
                        statusCell.Text = "🟡Pending";
                        break;
                    case "Approved":
                        statusCell.Text = "✅Approved";
                        break;
                    case "Rejected":
                        statusCell.Text = "❌Rejected";
                        break;
                }
            }
            else if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[2].Text = "Membership Number";
                e.Row.Cells[3].Text = "BOD Resolution Number";
                e.Row.Cells[4].Text = "ID Number";
                e.Row.Cells[5].Text = "Name";
                e.Row.Cells[6].Text = "Address";
                e.Row.Cells[7].Text = "Contact Number";
                e.Row.Cells[8].Text = "Sex";
                e.Row.Cells[9].Text = "Birthdate";
                e.Row.Cells[10].Text = "Age";
                e.Row.Cells[11].Text = "Assignment";
                e.Row.Cells[12].Text = "Referral Name";
                e.Row.Cells[13].Text = "Referral Address";
                e.Row.Cells[14].Text = "Referral Contact Number";
                e.Row.Cells[15].Text = "Status";
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}