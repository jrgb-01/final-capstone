﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace TestHomepage
{
    public partial class NewLoan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    //int signupID = (int)Session["SignupID"];
                    string username = Session["UserName"].ToString();
                }

                else
                {
                    // Redirect to login page if the user is not logged in
                    Response.Redirect("Login.aspx");
                }
            }
            logoutLink.ServerClick += new EventHandler(logoutLink_ServerClick);

        }
        void logoutLink_ServerClick(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }

        protected void ApplyButton_Click(object sender, EventArgs e)
        {
            string applicantName = Session["username"].ToString();

            // Generate a new LoanID
            string loanID = Guid.NewGuid().ToString();
            // Gather form data
            string loanType = LoanType.SelectedValue;
            decimal loanAmount = decimal.Parse(LoanAmount.Text);
            double loanTerm = double.Parse(LoanTerm.SelectedValue);
            string loanPurpose = LoanPurpose.Text;

            // Insert data into database
            string connectionString = "Data Source=JRLENOVO01;Initial Catalog=CapstoneDb;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Get the user's savings
                string savingsQuery = "SELECT Savings FROM Savings WHERE ApplicantName = @ApplicantName";
                SqlCommand savingsCommand = new SqlCommand(savingsQuery, connection);
                savingsCommand.Parameters.AddWithValue("@ApplicantName", applicantName);
                object result = savingsCommand.ExecuteScalar();
                decimal savings = (result == null) ? 0 : decimal.Parse(result.ToString());
                // Check if the savings is 0
                if (savings == 0)
                {
                    // Update the status message
                    StatusMessage.Text = "Your savings is 0. You cannot apply for a loan.";
                }
                // Check if the loan amount is less than or equal to 80% of the user's savings
                else if (loanAmount <= savings * 0.8m)
                {
                    string sqlQuery = "INSERT INTO Loans (LoanID, ApplicantName, LoanType, LoanAmount, LoanTerm, LoanPurpose, Status, DateSubmitted, IsProcessed) VALUES (@LoanID, @ApplicantName, @LoanType, @LoanAmount, @LoanTerm, @LoanPurpose, @Status, @DateSubmitted, @IsProcessed)";

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.Parameters.AddWithValue("@LoanID", loanID);
                        command.Parameters.AddWithValue("@ApplicantName", applicantName);
                        command.Parameters.AddWithValue("@LoanType", LoanType.SelectedValue);
                        command.Parameters.AddWithValue("@LoanAmount", decimal.Parse(LoanAmount.Text));
                        command.Parameters.AddWithValue("@LoanTerm", double.Parse(LoanTerm.SelectedValue));
                        command.Parameters.AddWithValue("@LoanPurpose", LoanPurpose.Text);
                        command.Parameters.AddWithValue("@Status", "Pending");
                        command.Parameters.AddWithValue("@DateSubmitted", DateTime.Now);
                        command.Parameters.AddWithValue("@IsProcessed", 0);

                        command.ExecuteNonQuery();
                    }

                    // Update the status message
                    StatusMessage.Text = "Your loan application has been submitted. Waiting for approval.";
                }
                else
                {
                    // Update the status message
                    StatusMessage.Text = "Your loan amount exceeds 80% of your savings. Please enter a smaller amount.";
                }
            }
        }
    }
}